/**
  ******************************************************************************
  * @file    Project/STM32F4xx_StdPeriph_Templates/stm32f4xx_it.c
  * @author  MCD Application Team
  * @version V1.5.0
  * @date    06-March-2015
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2015 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_it.h"
#include "./usart/bsp_debug_usart.h"

/** @addtogroup STM32F429I_DISCOVERY_Examples
  * @{
  */

/** @addtogroup FMC_SDRAM
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
    {
    }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
    {}
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
    {}
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
    {}
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{}

/**
  * @brief  This function handles PendSV_Handler exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{}

/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f429_439xx.s).                         */
/******************************************************************************/
#define ReceBuffLen	255
unsigned char get_usart1ReceiveBuff[ReceBuffLen]= {0};
unsigned char get_usart2ReceiveBuff[ReceBuffLen]= {0};
unsigned char get_usart3ReceiveBuff[ReceBuffLen]= {0};
unsigned char get_usart4ReceiveBuff[ReceBuffLen]={0};
void USART1_IRQHandler(void)
{
  uint8_t com_data;
  if(USART_GetITStatus(USART1,USART_IT_RXNE)!=RESET)
    {
//		ucTemp = USART_ReceiveData( USART1 );
//    USART_SendData(USART1,ucTemp);
      static unsigned char state=0;
      static unsigned char _data_len=0,DT_Data_cnt=0;
      com_data=USART1->DR;
      if(state==0&&com_data==0xA9)
        {
          state=1;
          get_usart1ReceiveBuff[0]=com_data;
        }
      else if(state==1&&com_data==0x9A)
        {
          state=2;
          get_usart1ReceiveBuff[1]=com_data;
        }
      else if(state==2)
        {
          state=3;
          get_usart1ReceiveBuff[2]=com_data;

          _data_len=com_data-3;
          DT_Data_cnt=0;
        }
      else if(state==3&&_data_len>0)
        {
          _data_len--;
          get_usart1ReceiveBuff[3+DT_Data_cnt++]=com_data;

          if(_data_len==0)
            {
              state=0;
              unsigned char CRC_GRAPHICS_BOADR=0x00;
              int i=0;
              for(i = 0; i < (get_usart1ReceiveBuff[2] - 2); i++)
                {
                  CRC_GRAPHICS_BOADR += get_usart1ReceiveBuff[i];
                }
              if(get_usart1ReceiveBuff[get_usart1ReceiveBuff[2] - 2] == CRC_GRAPHICS_BOADR)
                {
                  GPIO_ToggleBits(GPIOE, GPIO_Pin_7);

                  for( i = 0; i < (get_usart1ReceiveBuff[2]); i++)
                    {
                      USART_SendData(USART2,get_usart1ReceiveBuff[i]);
                      while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
                    }
                }

            }
        }
      else
        {
          state=0;
        }
    }

}


void USART2_IRQHandler(void)
{
  unsigned char com_data;
  if(USART_GetITStatus(USART2,USART_IT_RXNE)!=RESET)
    {
      static unsigned char state=0;
      unsigned char CRC_SPRUCE=0x00;
      static unsigned char _data_len=0,DT_Data_cnt=0;
      com_data=USART2->DR;
      if(state==0&&com_data==0xA9)
        {
          state=1;
          get_usart2ReceiveBuff[0]=com_data;

        }
      else if(state==1&&com_data==0x9A)
        {
          state=2;
          get_usart2ReceiveBuff[1]=com_data;

        }
      else if(state==2)//��ȡ���ݳ���
        {
          state=3;
          get_usart2ReceiveBuff[2]=com_data;

          _data_len=com_data-3;
          DT_Data_cnt=0;
        }
      else if(state==3&&_data_len>0)
        {
          _data_len--;
          get_usart2ReceiveBuff[3+DT_Data_cnt++]=com_data;

          if(_data_len==0)
            {
              state=0;
              int i=0;
              for( i=0; i<(get_usart2ReceiveBuff[2]-2); i++)
                {
                  CRC_SPRUCE+=get_usart2ReceiveBuff[i];
                }
              if(get_usart2ReceiveBuff[get_usart2ReceiveBuff[2]-2]==CRC_SPRUCE)
                {

                  switch(get_usart2ReceiveBuff[4])
                    {
                    case 0x21:
                    {
                      for( i=0; i<get_usart2ReceiveBuff[2]; i++)
                        {
                          USART_SendData(UART4, get_usart2ReceiveBuff[i]);
                          while(USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET);
                        }
                    };
                    break;
                    case 0x20:
                    {
                      CRC_SPRUCE=0x00;
                      unsigned char SPRUCE_Buffer[127]= {0},crc=0x00,t=0;
                      SPRUCE_Buffer[0]=0xAA;
                      int j=1;
                      for ( i=5; i<get_usart2ReceiveBuff[2]-2; i++)
                        {
                          SPRUCE_Buffer[j]=get_usart2ReceiveBuff[i];
                          j++;
                        }
                      unsigned char len=SPRUCE_Buffer[1]-1;
                      while(len--)
                        {
                          crc ^= SPRUCE_Buffer[t++];

                          for(unsigned char k = 8; k > 0; --k)
                            {
                              if(crc & 0x80)
                                {
                                  crc = (crc << 1) ^ 0xD5;
                                }
                              else
                                {
                                  crc = (crc << 1);
                                }
                            }
                        }
                      SPRUCE_Buffer[j] = crc;
                      for( i = 0; i < SPRUCE_Buffer[1]; i++)
                        {
                          USART_SendData(USART3,SPRUCE_Buffer[i]);
                          while(USART_GetFlagStatus(USART3,USART_FLAG_TXE)==RESET);
                        }
                    };
                    break;
                    case 0x22:
                    {
                      for( i=0; i<get_usart2ReceiveBuff[2]; i++)
                        {
                          USART_SendData(USART1,get_usart2ReceiveBuff[i]);
                          while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
                        }
                    };
                    break;
                    }
                }
              GPIO_ToggleBits(GPIOE,GPIO_Pin_7);

            }
        }
      else
        {
          state=0;
        }
    }


}


unsigned char RX_SPRUCE_COUNT=0x00;
unsigned char RX_SPRUCE_BUFF[1024]={0};
void USART3_IRQHandler(void)
{
  unsigned char com_data;
  if(USART_GetITStatus(USART3,USART_IT_RXNE)!=RESET)
    {
      static unsigned char state=0;
      static unsigned char _data_len=0,DT_Data_cnt=0;
      com_data=USART3->DR;
      if(state==0&&com_data==0xAA)
        {
          state=1;
          get_usart3ReceiveBuff[0]=com_data;
        }
      else if(state==1)
        {
          state=2;
          get_usart3ReceiveBuff[1]=com_data;
          _data_len=com_data-2;
          DT_Data_cnt=0;
        }
      else if(state==2&&_data_len>0)
        {
          _data_len--;
          get_usart3ReceiveBuff[2+DT_Data_cnt++]=com_data;
          if(_data_len==0)
            {
              state=0;
              RX_SPRUCE_BUFF[0] = 0xA9;
              RX_SPRUCE_BUFF[1] = 0x9A;
              RX_SPRUCE_BUFF[2] = 0x05 + get_usart3ReceiveBuff[1];
              RX_SPRUCE_BUFF[3] = RX_SPRUCE_COUNT;
              RX_SPRUCE_COUNT++;
              if(RX_SPRUCE_COUNT>255)
                {
                  RX_SPRUCE_COUNT=0x00;
                }
              RX_SPRUCE_BUFF[4] = 0x20;
              int j = 5;
							int k = 0;
              for( k = 1; k < get_usart3ReceiveBuff[1] - 1; k++)
                {
                  RX_SPRUCE_BUFF[j] = get_usart3ReceiveBuff[k];
                  j++;
                }

              RX_SPRUCE_BUFF[j] = 0x00;

              for( k = 0; k < RX_SPRUCE_BUFF[2] - 2; k++)
                {
                  RX_SPRUCE_BUFF[j] += RX_SPRUCE_BUFF[k];
                }

              RX_SPRUCE_BUFF[j + 1] = 0xAA;

//              for(int k = 0; k < RX_SPRUCE_BUFF[2]; k++)
//                {
//                  USART_SendData(USART2, &RX_SPRUCE_BUFF[k]);
//                  while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
//								}
              for( k = 0; k < get_usart3ReceiveBuff[1]; k++)
                {
                  USART_SendData(USART2, get_usart3ReceiveBuff[k]);
                  while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
                }
              GPIO_ToggleBits(GPIOE,GPIO_Pin_7);


            }
        }
      else
        {
          state=0;

        }
    }


}



void UART4_IRQHandler(void)
{
  unsigned char com_data;
  if(USART_GetITStatus(UART4,USART_IT_RXNE)!=RESET)
    {
			static unsigned char state=0;
      static unsigned char _data_len=0,DT_Data_cnt=0;
      com_data=UART4->DR;
			if(state==0&&com_data==0xA9)
        {
          state=1;
          get_usart4ReceiveBuff[0]=com_data;
        }
      else if(state==1&&com_data==0x9A)
        {
          state=2;
          get_usart4ReceiveBuff[1]=com_data;
        }
      else if(state==2)
        {
          state=3;
          get_usart4ReceiveBuff[2]=com_data;
          _data_len=com_data-3;
          DT_Data_cnt=0;
        }
      else if(state==3&&_data_len>0)
        {
          _data_len--;
          get_usart4ReceiveBuff[3+DT_Data_cnt++]=com_data;

          if(_data_len==0)
            {
              state=0;
              unsigned char CRC_SPRUCE=0x00;
              for(int i=0; i<(get_usart4ReceiveBuff[2]-2); i++)
                {
                  CRC_SPRUCE+=get_usart4ReceiveBuff[i];
                }
              if(get_usart4ReceiveBuff[get_usart4ReceiveBuff[2]-2]==CRC_SPRUCE)
                {
									for(int i=0; i<get_usart4ReceiveBuff[2]; i++)
                    {
                      USART_SendData(USART2, get_usart4ReceiveBuff[i]);
                      while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
                    }
                  GPIO_ToggleBits(GPIOE,GPIO_Pin_7);
                }

            }
        }
      else
        {
          state=0;
        }
    }
}

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
