#include "./uart/uart.h"


static void	NVIC_Configuration(void);


unsigned char get_usart1RxFlag=0;//串口1接收标志：0-未接收；1-接收
unsigned char get_usart1ReceiveBuff[RECEIVE_BUF_SIZE];//串口1接收缓冲
unsigned char get_usart1Len=0;//串口1接收长度

unsigned char get_usart2RxFlag=0;//串口2接收标志：0-未接收；1-接收
unsigned char get_usart2ReceiveBuff[RECEIVE_BUF_SIZE];//串口2接收缓冲
unsigned char get_usart2Len=0;//串口2接受长度

unsigned char get_usart3RxFlag=0;//串口3接收标志：0-未接收；1-接收
unsigned char get_usart3ReceiveBuff[RECEIVE_BUF_SIZE];//串口3接收缓冲
unsigned char get_usart3Len=0;//串口3接受长度

unsigned char get_usart4RxFlag=0;//串口4接收标志：0-未接收；1-接收
unsigned char get_usart4ReceiveBuff[RECEIVE_BUF_SIZE];//串口4接收缓冲
unsigned char get_usart4Len=0;//串口4接受长度

unsigned char get_usart5RxFlag=0;//串口5接收标志：0-未接收；1-接收
unsigned char get_usart5ReceiveBuff[RECEIVE_BUF_SIZE];//串口5接收缓冲
unsigned char get_usart5Len=0;//串口5接受长度

unsigned char get_usart6RxFlag=0;//串口6接收标志：0-未接收；1-接收
unsigned char get_usart6ReceiveBuff[RECEIVE_BUF_SIZE];//串口6接收缓冲
unsigned char get_usart6Len=0;//串口6接受长度

/**
 @brief 初始化串口1
 @param 无
 @param 无
 @retval 无
*/
void USART1_Config(void)
{
	GPIO_InitTypeDef 	GPIO_InitStructure;
	USART_InitTypeDef	USART_InitStructure;

	DEBUG_USART1_GPIO_AHB1ClkCmd(DEBUG_USART1_GPIO_CLK,ENABLE);
	DEBUG_USART1_APB2ClkCmd(DEBUG_USART1_CLK,ENABLE);
	//初始化引脚基本功能
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	
	//配置TX复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART1_TX_GPIO_PIN;
	GPIO_Init(DEBUG_USART1_TX_GPIO_PORT,&GPIO_InitStructure);

	//配置RX复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART1_RX_GPIO_PIN;
	GPIO_Init(DEBUG_USART1_RX_GPIO_PORT,&GPIO_InitStructure);

	//连接PA9到USART1_TX
	GPIO_PinAFConfig(DEBUG_USART1_TX_GPIO_PORT,DEBUG_USART1_TX_SOURCE,DEBUG_USART1_TX_AF);

	//连接PA10到USART1_RX
	GPIO_PinAFConfig(DEBUG_USART1_RX_GPIO_PORT,DEBUG_USART1_RX_SOURCE,DEBUG_USART1_RX_AF);

	//串口功能配置
	USART_InitStructure.USART_BaudRate=DEBUG_USART1_BAUDRATE;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b;
	USART_InitStructure.USART_StopBits=USART_StopBits_1;
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	USART_Init(DEBUG_USART1,&USART_InitStructure);
	
	NVIC_Configuration();

	USART_ITConfig(DEBUG_USART1,USART_IT_RXNE,ENABLE);

	USART_ITConfig(DEBUG_USART1,USART_IT_IDLE,ENABLE);

	USART_Cmd(DEBUG_USART1,ENABLE);

}
/**
 @brief 初始化串口2
 @param 无
 @param 无
 @retval 无
*/
void USART2_Config(void)
{
	GPIO_InitTypeDef 	GPIO_InitStructure;
	USART_InitTypeDef	USART_InitStructure;

	DEBUG_USART2_GPIO_AHB1ClkCmd(DEBUG_USART2_GPIO_CLK,ENABLE);
	DEBUG_USART2_APB1ClkCmd(DEBUG_USART2_CLK,ENABLE);

	//初始化引脚基本功能
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;

	//配置TX引脚复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART2_TX_GPIO_PIN;
	GPIO_Init(DEBUG_USART2_TX_GPIO_PORT,&GPIO_InitStructure);

	//配置RX引脚复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART2_RX_GPIO_PIN;
	GPIO_Init(DEBUG_USART2_RX_GPIO_PORT,&GPIO_InitStructure);

	//复用PD5到USART2_TX
	GPIO_PinAFConfig(DEBUG_USART2_TX_GPIO_PORT,DEBUG_USART2_TX_SOURCE,DEBUG_USART2_TX_AF);

	//复用PD6到USART2_RX
	GPIO_PinAFConfig(DEBUG_USART2_RX_GPIO_PORT,DEBUG_USART2_RX_SOURCE,DEBUG_USART2_RX_AF);

	//串口功能配置
	USART_InitStructure.USART_BaudRate=DEBUG_USART2_BAUDRATE;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b;
	USART_InitStructure.USART_StopBits=USART_StopBits_1;
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	USART_Init(DEBUG_USART2,&USART_InitStructure);


	USART_ITConfig(DEBUG_USART2,USART_IT_RXNE,ENABLE);

	USART_ITConfig(DEBUG_USART2,USART_IT_IDLE,ENABLE);

	USART_Cmd(DEBUG_USART2,ENABLE);

}
/**
 @brief 初始化串口3
 @param 无
 @param 无
 @retval 无
*/
void USART3_Config(void)
{
	GPIO_InitTypeDef 	GPIO_InitStructure;
	USART_InitTypeDef	USART_InitStructure;

	DEBUG_USART3_GPIO_AHB1ClkCmd(DEBUG_USART3_GPIO_CLK,ENABLE);
	DEBUG_USART3_APB1ClkCmd(DEBUG_USART3_CLK,ENABLE);

	//初始化引脚基本功能
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;

	//配置TX引脚复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART3_TX_GPIO_PIN;
	GPIO_Init(DEBUG_USART3_TX_GPIO_PORT,&GPIO_InitStructure);

	//配置RX引脚复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART3_RX_GPIO_PIN;
	GPIO_Init(DEBUG_USART3_RX_GPIO_PORT,&GPIO_InitStructure);

	//复用PB10到USART3_TX
	GPIO_PinAFConfig(DEBUG_USART3_TX_GPIO_PORT,DEBUG_USART3_TX_SOURCE,DEBUG_USART3_TX_AF);

	//复用PB11到USART3_RX
	GPIO_PinAFConfig(DEBUG_USART3_RX_GPIO_PORT,DEBUG_USART3_RX_SOURCE,DEBUG_USART3_RX_AF);

	//串口功能配置
	USART_InitStructure.USART_BaudRate=DEBUG_USART3_BAUDRATE;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b;
	USART_InitStructure.USART_StopBits=USART_StopBits_1;
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	USART_Init(DEBUG_USART3,&USART_InitStructure);


	USART_ITConfig(DEBUG_USART3,USART_IT_RXNE,ENABLE);

	USART_ITConfig(DEBUG_USART3,USART_IT_IDLE,ENABLE);

	USART_Cmd(DEBUG_USART3,ENABLE);

}
/**
 @brief 初始化串口4
 @param 无
 @param 无
 @retval 无
*/
void USART4_Config(void)
{
	GPIO_InitTypeDef 	GPIO_InitStructure;
	USART_InitTypeDef	USART_InitStructure;

	DEBUG_USART4_GPIO_AHB1ClkCmd(DEBUG_USART4_GPIO_CLK,ENABLE);
	DEBUG_USART4_APB1ClkCmd(DEBUG_USART4_CLK,ENABLE);

	//初始化引脚基本功能
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;

	//配置TX引脚复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART4_TX_GPIO_PIN;
	GPIO_Init(DEBUG_USART4_TX_GPIO_PORT,&GPIO_InitStructure);

	//配置RX引脚复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART4_RX_GPIO_PIN;
	GPIO_Init(DEBUG_USART4_RX_GPIO_PORT,&GPIO_InitStructure);

	//复用PA0到USART4_TX
	GPIO_PinAFConfig(DEBUG_USART4_TX_GPIO_PORT,DEBUG_USART4_TX_SOURCE,DEBUG_USART4_TX_AF);

	//复用PA1到USART4_RX
	GPIO_PinAFConfig(DEBUG_USART4_RX_GPIO_PORT,DEBUG_USART4_RX_SOURCE,DEBUG_USART4_RX_AF);

	//串口功能配置
	USART_InitStructure.USART_BaudRate=DEBUG_USART4_BAUDRATE;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b;
	USART_InitStructure.USART_StopBits=USART_StopBits_1;
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	USART_Init(DEBUG_USART4,&USART_InitStructure);


	USART_ITConfig(DEBUG_USART4,USART_IT_RXNE,ENABLE);

	USART_ITConfig(DEBUG_USART4,USART_IT_IDLE,ENABLE);

	USART_Cmd(DEBUG_USART4,ENABLE);

}

void USART5_Config(void)
{
	GPIO_InitTypeDef 	GPIO_InitStructure;
	USART_InitTypeDef	USART_InitStructure;

	DEBUG_USART4_GPIO_AHB1ClkCmd(DEBUG_USART5_RX_GPIO_CLK|DEBUG_USART5_TX_GPIO_CLK,ENABLE);
	DEBUG_USART4_APB1ClkCmd(DEBUG_USART5_CLK,ENABLE);

	//初始化引脚基本功能
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;

	//配置TX引脚复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART5_TX_GPIO_PIN;
	GPIO_Init(DEBUG_USART5_TX_GPIO_PORT,&GPIO_InitStructure);

	//配置RX引脚复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART5_RX_GPIO_PIN;
	GPIO_Init(DEBUG_USART5_RX_GPIO_PORT,&GPIO_InitStructure);

	//复用PC12到USART5_TX
	GPIO_PinAFConfig(DEBUG_USART5_TX_GPIO_PORT,DEBUG_USART5_TX_SOURCE,DEBUG_USART5_TX_AF);

	//复用PD2到USART5_RX
	GPIO_PinAFConfig(DEBUG_USART5_RX_GPIO_PORT,DEBUG_USART5_RX_SOURCE,DEBUG_USART5_RX_AF);

	//串口功能配置
	USART_InitStructure.USART_BaudRate=DEBUG_USART5_BAUDRATE;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b;
	USART_InitStructure.USART_StopBits=USART_StopBits_1;
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	USART_Init(DEBUG_USART5,&USART_InitStructure);


	USART_ITConfig(DEBUG_USART5,USART_IT_RXNE,ENABLE);

	USART_ITConfig(DEBUG_USART5,USART_IT_IDLE,ENABLE);

	USART_Cmd(DEBUG_USART5,ENABLE);

}


/**
 @brief 初始化串口6
 @param 无
 @param 无
 @retval 无
*/
void USART6_Config(void)
{
	GPIO_InitTypeDef 	GPIO_InitStructure;
	USART_InitTypeDef	USART_InitStructure;

	DEBUG_USART6_GPIO_AHB1ClkCmd(DEBUG_USART6_GPIO_CLK,ENABLE);
	DEBUG_USART6_APB2ClkCmd(DEBUG_USART6_CLK,ENABLE);
	//初始化引脚基本功能
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	
	//配置TX复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART6_TX_GPIO_PIN;
	GPIO_Init(DEBUG_USART6_TX_GPIO_PORT,&GPIO_InitStructure);

	//配置RX复用
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=DEBUG_USART6_RX_GPIO_PIN;
	GPIO_Init(DEBUG_USART6_RX_GPIO_PORT,&GPIO_InitStructure);

	//连接PC6到USART6_TX
	GPIO_PinAFConfig(DEBUG_USART6_TX_GPIO_PORT,DEBUG_USART6_TX_SOURCE,DEBUG_USART6_TX_AF);

	//连接PC7到USART6_RX
	GPIO_PinAFConfig(DEBUG_USART6_RX_GPIO_PORT,DEBUG_USART6_RX_SOURCE,DEBUG_USART6_RX_AF);

	//串口功能配置
	USART_InitStructure.USART_BaudRate=DEBUG_USART6_BAUDRATE;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b;
	USART_InitStructure.USART_StopBits=USART_StopBits_1;
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	USART_Init(DEBUG_USART6,&USART_InitStructure);

	USART_ITConfig(DEBUG_USART6,USART_IT_RXNE,ENABLE);

	USART_ITConfig(DEBUG_USART6,USART_IT_IDLE,ENABLE);

	USART_Cmd(DEBUG_USART6,ENABLE);

}




/**
 @brief 发送一个字节
 @param pUSARTx -[in] 串口
 @param ch -[in] 发送数据
 @retval 无
*/
void Usart_SendByte( USART_TypeDef * pUSARTx, unsigned char ch)
{
	/* 发送一个字节数据到USART */
	USART_SendData(pUSARTx,ch);
		
	/* 等待发送数据寄存器为空 */
	while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);	
}

/**
 @brief 发送8位的数组
 @param pUSARTx -[in] 串口
 @param array -[in] 发送数据
 @param num -[in] 发送长度
 @retval 无
*/
void Usart_SendArray( USART_TypeDef * pUSARTx, unsigned char *array, unsigned short int num)
{
  uint8_t i;
	
	for(i=0; i<num; i++)
  {
	    /* 发送一个字节数据到USART */
	    Usart_SendByte(pUSARTx,array[i]);	
  
  }
	/* 等待发送完成 */
	while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TC)==RESET);
}

/**
 @brief 发送字符串
 @param pUSARTx -[in] 串口
 @param str -[in] 发送数据
 @retval 无
*/
void Usart_SendString( USART_TypeDef * pUSARTx, char *str)
{
	unsigned int k=0;
  do 
  {
      Usart_SendByte( pUSARTx, *(str + k) );
      k++;
  } while(*(str + k)!='\0');
  
  /* 等待发送完成 */
  while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TC)==RESET)
  {}
}

/**
 @brief 发送一个16位数
 @param pUSARTx -[in] 串口
 @param ch -[in] 发送数据
 @retval 无
*/
void Usart_SendHalfWord( USART_TypeDef * pUSARTx, unsigned short int ch)
{
	uint8_t temp_h, temp_l;
	
	/* 取出高八位 */
	temp_h = (ch&0XFF00)>>8;
	/* 取出低八位 */
	temp_l = ch&0XFF;
	
	/* 发送高八位 */
	USART_SendData(pUSARTx,temp_h);	
	while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);
	
	/* 发送低八位 */
	USART_SendData(pUSARTx,temp_l);	
	while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);	
}
/**
 @brief 发送一个8位数
 @param pUSARTx -[in] 串口
 @param ch -[in] 发送数据
 @retval 无
*/
void Usart_SendHalfHalfWord( USART_TypeDef * pUSARTx, unsigned short int ch)
{
	uint8_t  temp_l;
	
	/* 取出低八位 */
	temp_l = ch&0XFF;
	
	/* 发送低八位 */
	USART_SendData(pUSARTx,temp_l);	
	while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);	
}
/**
 @brief 重定向c库函数printf到串口，重定向后可使用printf函数
*/
int fputc(int ch, FILE *f)
{
		/* 发送一个字节数据到串口 */
		USART_SendData(DEBUG_USART1, (uint8_t) ch);
		
		/* 等待发送完毕 */
		while (USART_GetFlagStatus(DEBUG_USART1, USART_FLAG_TXE) == RESET);		
	
		return (ch);
}

/**
 @brief 重定向c库函数scanf到串口，重写向后可使用scanf、getchar等函数
*/
int fgetc(FILE *f)
{
		/* 等待串口输入数据 */
		while (USART_GetFlagStatus(DEBUG_USART1, USART_FLAG_RXNE) == RESET);

		return (int)USART_ReceiveData(DEBUG_USART1);
}
/**
 @brief USART1中断
 @param 无
 @retval 无
*/
void USART1_IRQHandler(void)  
{  
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART1, USART_IT_RXNE); 

        get_usart1ReceiveBuff[get_usart1Len] = USART_ReceiveData(USART1);

        get_usart1Len++;
    }
    else if(USART_GetFlagStatus(USART1, USART_FLAG_IDLE) != RESET)
    {
        USART1->SR;
        USART1->DR;

        get_usart1RxFlag = 1;
    }
} 
/**
 @brief USART2中断
 @param 无
 @retval 无
*/
void USART2_IRQHandler(void)  
{  
    if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART2, USART_IT_RXNE); 

        get_usart2ReceiveBuff[get_usart2Len] = USART_ReceiveData(USART2);

        get_usart2Len++;
    }
    else if(USART_GetFlagStatus(USART2, USART_FLAG_IDLE) != RESET)
    {
        USART2->SR;
        USART2->DR;

        get_usart2RxFlag = 1;
    }
} 
/**
 @brief USART3中断
 @param 无
 @retval 无
*/
void USART3_IRQHandler(void)  
{  
    if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART3, USART_IT_RXNE); 

        get_usart3ReceiveBuff[get_usart3Len] = USART_ReceiveData(USART3);

        get_usart3Len++;
    }
    else if(USART_GetFlagStatus(USART3, USART_FLAG_IDLE) != RESET)
    {
        USART3->SR;
        USART3->DR;

        get_usart3RxFlag = 1;
    }
} 
/**
 @brief USART4中断
 @param 无
 @retval 无
*/
void UART4_IRQHandler(void)  
{  
    if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(UART4, USART_IT_RXNE); 

        get_usart4ReceiveBuff[get_usart4Len] = USART_ReceiveData(UART4);

        get_usart4Len++;
    }
    else if(USART_GetFlagStatus(UART4, USART_FLAG_IDLE) != RESET)
    {
        UART4->SR;
        UART4->DR;

        get_usart4RxFlag = 1;
    }
} 
/**
 @brief USART5中断
 @param 无
 @retval 无
*/
void UART5_IRQHandler(void)  
{  
    if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(UART5, USART_IT_RXNE); 

        get_usart5ReceiveBuff[get_usart5Len] = USART_ReceiveData(UART5);

        get_usart5Len++;
    }
    else if(USART_GetFlagStatus(UART5, USART_FLAG_IDLE) != RESET)
    {
        UART5->SR;
        UART5->DR;

        get_usart5RxFlag = 1;
    }
} 
/**
 @brief USART6中断
 @param 无
 @retval 无
*/
void USART6_IRQHandler(void)  
{  
    if(USART_GetITStatus(USART6, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART6, USART_IT_RXNE); 

        get_usart6ReceiveBuff[get_usart6Len] = USART_ReceiveData(USART6);

        get_usart6Len++;
    }
    else if(USART_GetFlagStatus(USART6, USART_FLAG_IDLE) != RESET)
    {
        USART6->SR;
        USART6->DR;

        get_usart6RxFlag = 1;
    }
} 
/*********************************************************************
 * LOCAL FUNCTIONS
 */
/**
 @brief  配置嵌套向量中断控制器NVIC
 @param  无
 @retval 无
*/
static void NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
  
	/* 嵌套向量中断控制器组选择 */
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

	/* 配置串口的 NVIC设置*/
	NVIC_InitStructure.NVIC_IRQChannel = DEBUG_USART1_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=DEBUG_USART2_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel=DEBUG_USART3_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=2;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=DEBUG_USART4_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=3;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=DEBUG_USART5_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=4;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=DEBUG_USART6_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=5;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	

}




