#ifndef __UART_H
#define __UART_H
#include "stm32f4xx.h"
#include "stdio.h"
#include "string.h"
#define RECEIVE_BUF_SIZE				1023


//USART1
#define DEBUG_USART1					USART1
#define DEBUG_USART1_CLK				RCC_APB2Periph_USART1
#define DEBUG_USART1_APB2ClkCmd			RCC_APB2PeriphClockCmd
#define DEBUG_USART1_BAUDRATE			115200

#define DEBUG_USART1_GPIO_CLK			RCC_AHB1Periph_GPIOA	
#define DEBUG_USART1_GPIO_AHB1ClkCmd	RCC_AHB1PeriphClockCmd

#define DEBUG_USART1_TX_GPIO_PORT		GPIOA
#define DEBUG_USART1_TX_GPIO_PIN		GPIO_Pin_9
#define DEBUG_USART1_TX_SOURCE			GPIO_PinSource9
#define DEBUG_USART1_TX_AF				GPIO_AF_USART1

#define DEBUG_USART1_RX_GPIO_PORT		GPIOA
#define DEBUG_USART1_RX_GPIO_PIN		GPIO_Pin_10
#define DEBUG_USART1_RX_SOURCE			GPIO_PinSource10
#define DEBUG_USART1_RX_AF				GPIO_AF_USART1

#define DEBUG_USART1_IRQ				USART1_IRQn
#define DEBUG_USART1_IRQHandler			USART1_IRQHandler

//USART2
#define DEBUG_USART2                   	USART2
#define DEBUG_USART2_CLK  				RCC_APB1Periph_USART2
#define DEBUG_USART2_APB1ClkCmd       	RCC_APB1PeriphClockCmd
#define DEBUG_USART2_BAUDRATE			115200

#define DEBUG_USART2_GPIO_CLK 			RCC_AHB1Periph_GPIOD
#define DEBUG_USART2_GPIO_AHB1ClkCmd	RCC_AHB1PeriphClockCmd

#define DEBUG_USART2_TX_GPIO_PORT		GPIOD
#define DEBUG_USART2_TX_GPIO_PIN		GPIO_Pin_5
#define DEBUG_USART2_TX_SOURCE			GPIO_PinSource5
#define DEBUG_USART2_TX_AF				GPIO_AF_USART2

#define DEBUG_USART2_RX_GPIO_PORT		GPIOD
#define DEBUG_USART2_RX_GPIO_PIN		GPIO_Pin_6
#define DEBUG_USART2_RX_SOURCE			GPIO_PinSource6
#define DEBUG_USART2_RX_AF				GPIO_AF_USART2

#define DEBUG_USART2_IRQ					USART2_IRQn
#define DEBUG_USART2_IRQHandler			USART2_IRQHandler

//USART3
#define DEBUG_USART3					USART3
#define DEBUG_USART3_CLK				RCC_APB1Periph_USART3
#define DEBUG_USART3_APB1ClkCmd			RCC_APB1PeriphClockCmd
#define DEBUG_USART3_BAUDRATE			115200

#define DEBUG_USART3_GPIO_CLK			RCC_AHB1Periph_GPIOB
#define DEBUG_USART3_GPIO_AHB1ClkCmd	RCC_AHB1PeriphClockCmd

#define DEBUG_USART3_TX_GPIO_PORT		GPIOB
#define DEBUG_USART3_TX_GPIO_PIN		GPIO_Pin_10
#define DEBUG_USART3_TX_SOURCE			GPIO_PinSource10
#define DEBUG_USART3_TX_AF				GPIO_AF_USART3

#define DEBUG_USART3_RX_GPIO_PORT		GPIOB
#define DEBUG_USART3_RX_GPIO_PIN		GPIO_Pin_11
#define DEBUG_USART3_RX_SOURCE			GPIO_PinSource11
#define DEBUG_USART3_RX_AF				GPIO_AF_USART3

#define DEBUG_USART3_IRQ				USART3_IRQn
#define DEBUG_USART3_IRQHandler			USART3_IRQHandler

//USART4
#define DEBUG_USART4									UART4
#define DEBUG_USART4_CLK							RCC_APB1Periph_UART4
#define DEBUG_USART4_APB1ClkCmd				RCC_APB1PeriphClockCmd
#define DEBUG_USART4_BAUDRATE					115200

#define DEBUG_USART4_GPIO_CLK					RCC_AHB1Periph_GPIOA
#define DEBUG_USART4_GPIO_AHB1ClkCmd	RCC_AHB1PeriphClockCmd

#define DEBUG_USART4_TX_GPIO_PORT			GPIOA
#define DEBUG_USART4_TX_GPIO_PIN			GPIO_Pin_0
#define DEBUG_USART4_TX_SOURCE				GPIO_PinSource0
#define DEBUG_USART4_TX_AF						GPIO_AF_UART4

#define DEBUG_USART4_RX_GPIO_PORT			GPIOA
#define DEBUG_USART4_RX_GPIO_PIN			GPIO_Pin_1
#define DEBUG_USART4_RX_SOURCE				GPIO_PinSource1
#define DEBUG_USART4_RX_AF						GPIO_AF_UART4

#define DEBUG_USART4_IRQ							UART4_IRQn

//USART5
#define DEBUG_USART5									UART5
#define DEBUG_USART5_CLK							RCC_APB1Periph_UART5
#define DEBUG_USART5_APB1ClkCmd				RCC_APB1PeriphClockCmd
#define DEBUG_USART5_BAUDRATE					115200

#define DEBUG_USART5_TX_GPIO_CLK			RCC_AHB1Periph_GPIOC
#define DEBUG_USART5_RX_GPIO_CLK			RCC_AHB1Periph_GPIOD
#define DEBUG_USART5_GPIO_AHB1ClkCmd	RCC_AHB1PeriphClockCmd

#define DEBUG_USART5_TX_GPIO_PORT			GPIOC
#define DEBUG_USART5_TX_GPIO_PIN			GPIO_Pin_12
#define DEBUG_USART5_TX_SOURCE				GPIO_PinSource12
#define DEBUG_USART5_TX_AF						GPIO_AF_UART5

#define DEBUG_USART5_RX_GPIO_PORT			GPIOD
#define DEBUG_USART5_RX_GPIO_PIN			GPIO_Pin_2
#define DEBUG_USART5_RX_SOURCE				GPIO_PinSource2
#define DEBUG_USART5_RX_AF						GPIO_AF_UART5

#define  DEBUG_USART5_IRQ							UART5_IRQn

//USART6
#define DEBUG_USART6					USART6
#define DEBUG_USART6_CLK				RCC_APB2Periph_USART6
#define DEBUG_USART6_APB2ClkCmd			RCC_APB2PeriphClockCmd
#define DEBUG_USART6_BAUDRATE			115200

#define DEBUG_USART6_GPIO_CLK			RCC_AHB1Periph_GPIOC	
#define DEBUG_USART6_GPIO_AHB1ClkCmd	RCC_AHB1PeriphClockCmd

#define DEBUG_USART6_TX_GPIO_PORT		GPIOC
#define DEBUG_USART6_TX_GPIO_PIN		GPIO_Pin_6
#define DEBUG_USART6_TX_SOURCE			GPIO_PinSource6
#define DEBUG_USART6_TX_AF				GPIO_AF_USART6

#define DEBUG_USART6_RX_GPIO_PORT		GPIOC
#define DEBUG_USART6_RX_GPIO_PIN		GPIO_Pin_7
#define DEBUG_USART6_RX_SOURCE			GPIO_PinSource7
#define DEBUG_USART6_RX_AF				GPIO_AF_USART6

#define DEBUG_USART6_IRQ				USART6_IRQn

extern unsigned char get_usart1RxFlag;//串口1接收标志：0-未接收；1-接收
extern unsigned char get_usart1ReceiveBuff[RECEIVE_BUF_SIZE];//接收数组
extern unsigned char get_usart1Len;//串口1接收长度

extern unsigned char get_usart2RxFlag;//串口2接收标志：0-未接收；1-接收
extern unsigned char get_usart2ReceiveBuff[RECEIVE_BUF_SIZE];//串口2接收缓冲
extern unsigned char get_usart2Len;//串口2接受长度

extern unsigned char get_usart3RxFlag;//串口3接收标志：0-未接收；1-接收
extern unsigned char get_usart3ReceiveBuff[RECEIVE_BUF_SIZE];//串口3接收缓冲
extern unsigned char get_usart3Len;//串口3接受长度

extern unsigned char get_usart4RxFlag;//串口4接收标志：0-未接收；1-接收
extern unsigned char get_usart4ReceiveBuff[RECEIVE_BUF_SIZE];//串口4接收缓冲
extern unsigned char get_usart4Len;//串口4接受长度

extern unsigned char get_usart5RxFlag;//串口5接收标志：0-未接收；1-接收
extern unsigned char get_usart5ReceiveBuff[RECEIVE_BUF_SIZE];//串口5接收缓冲
extern unsigned char get_usart5Len;//串口5接受长度

extern unsigned char get_usart6RxFlag;//串口6接收标志：0-未接收；1-接收
extern unsigned char get_usart6ReceiveBuff[RECEIVE_BUF_SIZE];//串口6接收缓冲
extern unsigned char get_usart6Len;//串口6接受长度

void USART1_Config(void);
void USART2_Config(void);
void USART3_Config(void);
void USART4_Config(void);
void USART5_Config(void);
void USART6_Config(void);
void Usart_SendByte( USART_TypeDef * pUSARTx, unsigned char ch);
void Usart_SendArray( USART_TypeDef * pUSARTx, unsigned char *array, unsigned short int num);
void Usart_SendString( USART_TypeDef * pUSARTx, char *str);
void Usart_SendHalfWord( USART_TypeDef * pUSARTx, unsigned short int ch);
void Usart_SendHalfHalfWord( USART_TypeDef * pUSARTx, unsigned short int ch);

#endif

