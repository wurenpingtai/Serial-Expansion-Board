#ifndef __DEBUG_USART_H
#define	__DEBUG_USART_H

#include "stm32f4xx.h"
#include <stdio.h>

void Debug_USART1_Config(void);
void Debug_USART2_Config(void);
void Debug_USART3_Config(void);
void Debug_USART4_Config(void);


#endif /* __USART1_H */
